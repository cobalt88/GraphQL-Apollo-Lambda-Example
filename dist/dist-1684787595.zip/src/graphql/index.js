import Query from "./resolvers.js";
import typeDefs from "./typedefs.js";
const resolvers = {
	Query,
};

export { resolvers, typeDefs };
