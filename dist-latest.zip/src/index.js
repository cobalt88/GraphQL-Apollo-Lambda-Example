exports.handler = async () => {
	return {
		body: "Hello From Lambda!",
	};
};
